<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./style/style.css">
    <title>Le monde des livres</title>
  </head>
  <body>
    <div>
      Créez votre compte : 
      <form method="post" action="auth.php">
        <label>Username</label>
        <input type="text" name="name">
        <label>Password</label>
        <input type="text" name="password">
        <input type="submit" value="register !">
      </form>
    </div>
    <div class="title">
      <h1>Achat</h1>
      <h1>de</h1>
      <h1>livres</h1>
    </div>

    <div class="connection">
      <form class="" action="./page.php" method="post">
        <label for="Nom">Nom d'utilisateur :</label>
        <input type="text" name="name" value="" maxlength="25">
        <label for="password">Mot de passe :</label>
        <input type="text" name="password" value="" maxlength="25">
        <input type="submit" name="" value="Ok!">
      </form>
    </div>
  </body>
</html>

<?php
session_start();

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./style/style.css">
    <title>Le monde des livres</title>
  </head>
  <body>
    <div class="title">
      <h1>Votre Panier</h1>
    </div>
  </body>
</html>

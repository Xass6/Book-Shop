<?php
function getAllLivres() {
  $request = '
  SELECT id, name, prix
  FROM livre
  ';
  $connec = new PDO('mysql:dbname=Livres', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare($request);
  $request->execute();
  return $request->fetchAll();
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css?family=Charm" rel="stylesheet">
    <title>Le monde des livres</title>
  </head>
  <body>
    <a href="panier.php"><img class="Panier" src="shop.png" alt="Panier"/></a>
    <div class="livre"> Le Monde des Livres</div>
      <?php
      echo '<div class="main">
      <div class="Hello">Bonjour ' . $_POST['name'] . '</div>';
      $livres = GetAllLivres();
      echo '<div class="card">';
      foreach ($livres as $key => $livre):
        echo '
            <div class="book">
            <p> ' . $livre['name'] . '</p>
            <p> ' . $livre['prix'] . '</p>
            <form method="get" action="panier.php">
              <button>Panier</button>
            </form>
            </div>';
      endforeach;
      echo " </div>";?>
  </body>
</html>

<?php


function getAllUser() {
  $request = '
  SELECT *
  FROM  Users
  ';
  $connec = new PDO('mysql:dbname=Livres', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare($request);
  $request->execute();
  return $request->fetchAll();
}

$users = getAllUser();
$userName = $_POST['name'];
$userPassword = $_POST['password'];

foreach ($users as $key => $user) {
   if (in_array($userName, $user)) {
     echo "username already used";
     return true;
   }else {
     echo "";
   }
 }
 $connec = new PDO('mysql:dbname=Livres', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare('INSERT INTO Users (name, password) VALUES (:name, :password)');
  $request->execute([
    ":name" => $userName,
    ":password" => $userPassword,
  ]);
    echo "Vous êtes enregistrée !";

 ?>

<?php
session_start();
  function getAllUser() {
    $request = '
    SELECT *
    FROM  Users
    ';
    $connec = new PDO('mysql:dbname=Livres', 'root', '0000');
    $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $request = $connec->prepare($request);
    $request->execute();
    return $request->fetchAll();
  }
  $users = getAllUser();

    foreach ($users as $user) {
      $name = $_POST["name"];
      $password = $_POST["password"];
        if (in_array($name, $user) && in_array($password,$user)) {
            return require_once('./produits.php');
        }
      };
      echo " Vous n'êtes pas enregistré.";
 ?>
